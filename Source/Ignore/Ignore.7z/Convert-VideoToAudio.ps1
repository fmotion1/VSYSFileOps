<#
.SYNOPSIS
    Converts a wide variety of video formats to MP3, FLAC, WAV, or AIF

.DESCRIPTION
    Converts a wide variety of video formats to MP3, FLAC, WAV, or AIF
    Formats supported include: (.MP4 .MKV .WEBM .AVI .MPEG .MPG .MOV .WMV .FLV)

.PARAMETER SourceFiles
    A path to a video or an array of video paths to convert.

.PARAMETER Format
    The target format for conversion. Acceptable values are: 
    MP3, FLAC, WAV, or AIF
    Default is MP3.

.PARAMETER MP3Bitrate
    The target bitrate for MP3 conversions. Default is 320k. Acceptable values are:
    128k, 192k, 320k, VBR
    Default is 320k.

.PARAMETER BitDepth
    The target bit depth for WAV or AIF. Acceptable values are:
    8bit, 16bit, 24bit, 32bit
    Default is 16bit.

.PARAMETER SampleRate
    The target sample rate for WAV and AAC conversions. Acceptable values are:
    44.1kHz, 48kHz, 96kHz
    Default is 44.1kHz

.EXAMPLE
    Convert-VideoToAudio -SourceFiles "C:\Music\SomeVideo.mp4" -Format "MP3" -MP3Bitrate "320k"

.INPUTS
    String[]

.OUTPUTS
    Nothing.

.NOTES
    Name: Convert-VideoToAudio
    Author: Visusys
    Release: 1.0.0
    License: MIT License
    DateCreated: 2021-12-10

.LINK
    https://github.com/visusys

.LINK
    Get-VideoAudioStreams
    
#>
function Convert-VideoToAudio {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [ValidateScript({
                if (!(Test-Path -LiteralPath $_)) {
                    throw [System.ArgumentException] "File does not exist." 
                }
                if (!(Test-Path -LiteralPath $_ -PathType Leaf)) {
                    throw [System.ArgumentException] "A folder was passed when a file was expected." 
                }
                if ($_ -notmatch "(\.mp4|\.m4v|\.mkv|\.webm|\.avi|\.mpeg|\.mpg|\.mov|\.wmv|\.flv)") {
                    throw [System.ArgumentException] "The file specified ($_) must be a supported video filetype."
                }
                return $true
            })]
        [String[]]
        $SourceFiles,

        [Parameter(Mandatory = $false, ValueFromPipelineByPropertyName)]
        [ValidateScript({
                if ($_ -notmatch "MP3|FLAC|WAV|AIF") {
                    throw [System.ArgumentException] "Specified output format is invalid."
                }
                return $true
            })]
        [String]
        $Format = "MP3",

        [Parameter(Mandatory = $false, ValueFromPipelineByPropertyName)]
        [ValidateSet(0,1,2,3,4,5,6,7,8,9,"128","192","256","320", IgnoreCase = $true)]
        [String]
        $MP3Bitrate = "0"
    )

    # -ar[:stream_specifier] freq (input/output,per-stream)
    # 96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350
    # Set the audio sampling frequency. For output streams it is set 
    # by default to the frequency of the corresponding input stream. 
    # For input streams this option only makes sense for audio grabbing 
    # devices and raw demuxers and is mapped to the corresponding 
    # demuxer options. 

    $Duplicates = @{}
    $SourceFiles | ForEach-Object {

        $OriginalFile = [System.IO.Path]::GetFullPath($_)
        $FileDetails = ffprobe -loglevel 0 -print_format json -show_format -show_streams "$OriginalFile" | ConvertFrom-Json

        $AudioStreamsList = [System.Collections.Generic.List[object]]@()
        for ($i = 0; $i -lt $FileDetails.streams.Count; $i++) {
            if(($FileDetails.streams[$i].codec_type) -eq 'audio'){
                $Obj = [PSCustomObject][ordered]@{
                    CodecName       = $FileDetails.streams[$i].codec_name
                    CodecLongName	= $FileDetails.streams[$i].codec_long_name
                    SampleRate	    = $FileDetails.streams[$i].sample_rate
                    BitDepth	    = $FileDetails.streams[$i].sample_fmt
                    Channels	    = $FileDetails.streams[$i].channels
                    ChannelLayout   = $FileDetails.streams[$i].channel_layout
                    BitRate         = $FileDetails.streams[$i].bit_rate
                    Language        = $FileDetails.streams[$i].tags.language
                    Title           = $FileDetails.streams[$i].tags.title
                }
                $AudioStreamsList.Add($Obj)
            }
        }

        if($AudioStreamsList.Count -gt 0){
            for ($i = 0; $i -lt $AudioStreamsList.Count; $i++) {

                if($OutputPath){
                    if(!(Test-Path -LiteralPath $OutputPath)){
                        New-Item -Path $OutputPath -ItemType Directory -Force
                    }
                }
            
                $OriginalFileFolder = [System.IO.Path]::GetDirectoryName($OriginalFile)
                $FileBaseName = [System.IO.Path]::GetFileNameWithoutExtension($OriginalFile)
                
                $AudioStream = $AudioStreamsList[$i]
                $NewExtension = $FileFormats[$AudioStream.CodecName]
                if(!($NewExtension)) {
                    Write-Warning "Codec "$AudioStream.CodecName" has not been implemented yet. Skipping this file."
                    Break
                }

                if($AudioStream.Language){
                    $FileBaseName = $FileBaseName+" "+$AudioStream.Language.toUpper()
                    if($AudioStream.Title){
                        $FileBaseName = $FileBaseName+" "+$AudioStream.Title
                    }
                }

                if($OutputPath){
                    $NewAudioFile = ([System.IO.Path]::Combine($OutputPath, $FileBaseName)) + ".$NewExtension"
                }else{
                    $NewAudioFile = ([System.IO.Path]::Combine($OriginalFileFolder, $FileBaseName)) + ".$NewExtension"
                }

                if($Duplicates.Contains($NewAudioFile)){
                    if($OutputPath){
                        $BasePath = [System.IO.Path]::Combine($OutputPath, $FileBaseName)
                    }else{
                        $BasePath = [System.IO.Path]::Combine($OriginalFileFolder, $FileBaseName)
                    }
                    $NewName = ('{0}_{1}{2}' -f @(
                    $BasePath
                    ($Duplicates[$NewAudioFile].ToString().PadLeft(2, '0')) + '.'
                    $NewExtension
                ))} else {
                    $NewName = $NewAudioFile
                }

                $Duplicates[$NewName]++

                $NewName = '"{0}"' -f $NewName
                
                Write-Verbose "`$OriginalFile:              $OriginalFile" 
                Write-Verbose "`$OriginalFileFolder:        $OriginalFileFolder"
                Write-Verbose "`$FileBaseName:              $FileBaseName"
                Write-Verbose "`$NewExtension:              $NewExtension" 
                Write-Verbose "`$NewAudioFile:              $NewAudioFile"
                Write-Verbose "`$NewName:                   $NewName"  
                Write-Verbose "`$AudioStream.CodecName:     $($AudioStream.CodecName)"
                Write-Verbose "`$AudioStream.CodecLongName: $($AudioStream.CodecLongName)"
                Write-Verbose "`r`n"
                

                switch ($AudioStream.CodecName) {
                    'truehd' { 
                        & ffmpeg -loglevel fatal -vn -sn -dn -i $OriginalFile -map 0:a:$i -bsf:a truehd_core -c:a copy $NewName
                    }
                    # adpcm_ima_qt is broken, so we convert to .wav
                    'adpcm_ima_qt' {
                        & ffmpeg -loglevel fatal -vn -sn -dn -i $OriginalFile -map 0:a:$i $NewName
                    }
                    default {
                        & ffmpeg -loglevel fatal -vn -sn -dn -i $OriginalFile -map 0:a:$i -c:a copy $NewName
                    }
                } 
            }
        }
    }
    
}

