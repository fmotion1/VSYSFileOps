
<#
.SYNOPSIS
    A wrapper function for the ImportExcel module.
    Exports a PSCustomObject to an Excel XLSX file.

    Requires ImportExcel 7.4.1.

.DESCRIPTION
    Exports a PSCustomObject to an Excel XLSX file.
    Optionally define a Worksheet Name.

.PARAMETER InputObject
    The object you want to export.

.PARAMETER ExportPath
    The filepath you want to save the XLSX document to.

.PARAMETER Worksheet
    The worksheet name you want to save your data to. (Optional)

.EXAMPLE
    Export-ExcelPSObjectToXLSX $DatabaseObj -ExportPath "C:\Docs\Database.xlsx" -Worksheet "Database1"

.INPUTS
    Object

.OUTPUTS
    None.
    Creates an Excel XLSX file.

.NOTES
    Name: Export-ExcelPSObjectToXLSX
    Author: Visusys
    Release: 1.0.0
    License: MIT License
    DateCreated: 2022-04-15

.LINK
    https://github.com/visusys
    
#>
function Export-ExcelPSObjectToXLSX {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory,ValueFromPipeline)]
        $InputObject,

        [Parameter(Mandatory,Position=0)]
        [ValidateScript({
            if ($_ -notmatch "(\.xlsx)") {
                throw [System.ArgumentException] "The passed filename doesn't have an xlsx extension."
            }
            return $true
        })]
        [String]
        $ExportPath,

        [Parameter(Mandatory=$false)]
        [String]
        $Worksheet = "Default",

        [Parameter(Mandatory=$false)]
        [String]
        $TableName = "DefaultTable",

        [Parameter(Mandatory=$false)]
        [Switch]
        $NoAutoSize
    )

    #Requires -Modules @{ ModuleName="ImportExcel"; ModuleVersion="7.4.1" }

    begin {
        Write-Verbose "Begin Block"
        $AllInput = [System.Collections.Generic.List[object]]::new()
    }

    process {
        #Write-Verbose "Process Block"
        if ($PSCmdlet.MyInvocation.ExpectingInput) {
            "Data received from pipeline input"
            $AllInput.Add($InputObject)
        }
        else {
            "Data received from parameter input"
            $AllInput = $InputObject
        }
        
    }

    end {

        
        Write-Verbose "End Block"
        

        $params = @{
            AutoSize        = !($NoAutoSize)
            Show            = $true
            InputObject     = $AllInput
            Path            = $ExportPath
            TableName       = $TableName
            WorksheetName   = $Worksheet
            PassThru        = $true
            
        }
        
        $xlsx = Export-Excel @params
        $ws = $xlsx.Workbook.Worksheets[$params.Worksheetname]
        $ws.View.ShowGridLines = $true
        Close-ExcelPackage $xlsx

        #Write-Host "`$params.AutoSize:" ($params.AutoSize) -ForegroundColor Green
        
        
    }
}

# Get-Service | Export-Excel "C:\Users\futur\Desktop\Processes.xlsx" -show
# Get-Service | Export-ExcelPSObjectToXLSX -ExportPath "C:\Users\futur\Desktop\Services.xlsx" -Verbose
# Export-ExcelPSObjectToXLSX -ExportPath "C:\Users\futur\Desktop\Processes.xlsx" -InputObj (Get-Service) -Verbose

