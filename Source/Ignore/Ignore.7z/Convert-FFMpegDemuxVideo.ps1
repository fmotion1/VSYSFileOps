Function Convert-FFMpegDemuxVideo {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, Position = 0, ValueFromPipeline, ValueFromPipelineByPropertyName)]
        [ValidateScript({
                if (!(Test-Path -LiteralPath $_)) {
                    throw [System.ArgumentException] "File does not exist." 
                }
                if (!(Test-Path -LiteralPath $_ -PathType Leaf)) {
                    throw [System.ArgumentException] "A folder was passed when a file was expected." 
                }
                if ($_ -notmatch '(\.mp4|\.m4v|\.mkv|\.webm|\.avi|\.mpeg|\.mpg|\.mov|\.wmv|\.flv)$') {
                    throw [System.ArgumentException] "The file specified ($_) must be a supported video filetype."
                }
                return $true
            })]
        [String[]]
        $SourceFiles,

        [Parameter(Mandatory = $false, ValueFromPipelineByPropertyName)]
        [String]
        $OutputPath
    )

    process {

        $FileFormats = @{
            hevc        = @('mp4','mkv')
            h263        = @('mp4','m4v','mkv','mov')
            h264        = @('mp4','m4v','mkv','mov')
            svq3        = @('mov')
            svq1        = @('mov')
            mpeg4       = @('mov')
            cinepak     = @('mov')
            rv40        = @('mkv','webm')
            flv1        = @('flv')
            wmv3        = @('wmv')
            wmv2        = @('wmv')
            mpeg1video  = @('mpg','mpeg')
            mpeg2video  = @('mpg','mpeg')
            msmpeg4v2   = @('avi')
            msmpeg4v3   = @('wmv')
            vp6f        = @('flv')
            mjpeg       = @('avi')
            vp9         = @('webm')
            rawvideo    = @('mp4','m4v','mkv','mov')
        }

        $SourceFiles | ForEach-Object {

            $FileOriginal   = [System.IO.Path]::GetFullPath($_)
            $FileOrigName   = [System.IO.Path]::GetFileName($FileOriginal)
            $FileOrigBase   = [System.IO.Path]::GetFileNameWithoutExtension($FileOriginal)
            $FileOrigFolder = [System.IO.Path]::GetDirectoryName($FileOriginal)

            $VideoStream  = Convert-FFMpegGetVideoStreams $FileOriginal -StreamType 'Video'

            if (!($VideoStream)) {
                Write-Verbose "No video streams exist in $FileOriginal. Skipping."
                return
            }

            $VideoStream

            try{
                $NewExtension = ($FileFormats[$VideoStream.CodecName])[0]
                Write-Host "`$NewExtension:" $NewExtension -ForegroundColor Green
            }catch{
                Write-Verbose "Unhandled extension! $FileOrigName"
                return
            }

            if ($OutputPath) {
                if (!(Test-Path -LiteralPath $OutputPath)) {
                    New-Item -Path $OutputPath -ItemType Directory -Force
                }
                $NewVideoFile = ([System.IO.Path]::Combine($OutputPath, $FileOrigBase)) + '_demux' + ".$NewExtension"
            }else{
                $NewVideoFile = ([System.IO.Path]::Combine($FileOrigFolder, $FileOrigBase)) + '_demux' + ".$NewExtension"
            }

            $NewName = $NewVideoFile
            $NewName = '"{0}"' -f $NewName

            & ffmpeg -loglevel warning -an -sn -dn -i $FileOriginal -c:v copy $NewName

            
        }

        Write-Output "Completed conversion."
    }
}
$VideoArr = @(
    "C:\Users\futur\Desktop\Testing\Video Files\Generic 1\00 What is Material Builder.mp4"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\00-IntroMsFeb.mp4"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\0.Trailer.mp4"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\01 Introduction.mkv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\01 Take Me To Chelsea PB 12.wmv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\01_spartanHelmet_imagePlanes.m4v"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\01. Introduction.m4v"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\02 - Baking maps used in the texturing process.webm"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\02 - Where, What & Why.m4v"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\02 Gathering reference images.mkv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\02 Long Way Down Tonight PB 13.wmv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\02 Quick start Part 1.mkv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\02. Maya Projects And Interface.m4v"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\03 - Creating the base paint material.webm"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\03 - Viewport Shading.m4v"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\04 - Creating a preview for your project.webm"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\16bit.mov"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\000023.flv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\000028.flv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\037 - Setting track value boundaries with a limit controller.mp4"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\038 - Drawing curves with Freehand Spline.mp4"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\1280.avi"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\AtlRedux1.mpeg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Aurora_trailer.avi"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Bear In The Woods.avi"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\big_buck_bunny_720p_30mb.flv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\big_buck_bunny_720p_30mb.mkv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Block-707 (TT_03).webm"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\bs4_e3.mpeg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Buck.AVI"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Bumblebee.mpg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\ChimeraBTS.mov"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\CNN.mpg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Cow Jumps.mpg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Cowboy Bebop - The Movie.avi"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\DaVinci_Teaser.mpeg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\DC No Quarter.wmv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\DLP_PART_2_768k.mov"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Drac_Dragon_trailer.flv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Fables_teaser.flv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\FirenzePolizia.mov"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\first_vampire1.flv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Ghost in the Shell.mpg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\ghostbusters-afterlife-trailer-2_h1080p.mov"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\gta3-en_us-10thanniversary-wmv-1280.wmv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Indystaff_debut_trailer.wmv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\IP Suisse_Basisspot D42.mpg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\jira-over.mov"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\lion-sample.m4v"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\MadMaraca Simulation.mp4"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\MadMaraca Transcend.mp4"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\metaxas-keller-Bell.avi"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\ObscureIntro.mpeg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Obscuretrailer.mpg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\page18-movie-4.flv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Panasonic_HDC_TM_700_P_50i.avi"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\resident-evil-welcome-to-raccoon-city-final-trailer_h1080p.mov"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\rh2007lower.mov"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\sample_960x400_ocean_with_audio.avi"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\sample_960x400_ocean_with_audio.flv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\sample_960x400_ocean_with_audio.mpeg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\sample_960x400_ocean_with_audio.wmv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\sample_1280x720_surfing_with_audio.avi"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\sample_1280x720_surfing_with_audio.mpeg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\sample-mpg-file.mpg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Skyscraper Complex 5.mp4"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\sonic-the-hedgehog-2-trailer-1_h1080p.mov"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\sonic-the-hedgehog-2-trailer-1_i320.m4v"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Spirited Away.avi"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\t_supermariogalaxy_demo_gp2_e36.wmv"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\TonyTough.mpg"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Trailer.avi"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Veterans_Sabrina_Beck_.mpeg.HD.mp4"
"C:\Users\futur\Desktop\Testing\Video Files\Generic 1\wild-game-trailer-1_h1080p.mov"
)

Convert-FFMpegDemuxVideo $VideoArr -OutputPath "C:\Users\futur\Desktop\Testing\Video Files\Generic 1\Output" -Verbose