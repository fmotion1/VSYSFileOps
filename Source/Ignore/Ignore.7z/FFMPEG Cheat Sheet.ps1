# FFMPEG Cheat Sheet
# 
# ffmpeg -formats	 Containers (Formats)
# ffmpeg -codecs	  Codecs
# ffmpeg -muxers	  Muxers
# ffmpeg -demuxers	Demuxers
# ffmpeg -encoders	Processes used to encode
# ffmpeg -decoders	Processes used to decode
# 
# https://ffmpeg.org/ffmpeg-formats.html#Description
# 
# 
# A codec is the logic to encoding or decoding a media stream, there are many 
# different types with popular ones being H.264, HEVC (H.265) and MPEG-4.
# 
# Codecs are different to containers like MP4, MKV and MOV because a codec 
# manages the bitrate, resolution and frames whilst the container organizes 
# and returns the data as sequence.
# 
# -vcodec codec (output)
# Set the video codec. This is an alias for -codec:v.
# -codec is the same as -c
# -c[:stream_specifier] codec (input/output,per-stream)
# -codec[:stream_specifier] codec (input/output,per-stream)
# :v, :a, :s are Stream Specifiers (http://ffmpeg.org/ffmpeg-all.html#Stream-specifiers)
# 
# -acodec is a subset that automatically scopes to Audio streams
# -acodec:1 is the same as -codec:a:1 and indicates you are setting the codec 
# for the second audio stream (the first audio stream is 0).
# 
# -c copy	   = -acodec copy -vcodec copy
# -c:a copy	 = -acodec copy
# -c:v copy	 = -vcodec copy
# -codec:a copy = -c:a copy
# 
# -copy
# Stream copy is a mode selected by supplying the copy parameter to the -codec option. 
# It makes ffmpeg omit the decoding and encoding step for the specified stream, 
# so it does only demuxing and muxing. It is useful for changing the container 
# format or modifying container-level metadata.
# 
# -c:a copy means that the input audio will be copied as is, without any transcoding. 
# So if your input has mp3 audio, the output will also be mp3, an exact copy of the input.
# 
# The -vn / -an / -sn / -dn options can be used to skip inclusion of 
# video, audio, subtitle and data streams respectively
# 
# ffmpeg -i INPUT -map 0 -c copy -c:v:1 libx264 -c:a:137 libvorbis OUTPUT
# This is saying use the original codec for all the steams (-c copy), but for the 
# second video stream use libx264 (-c:v:1 libx264), and for the 138th audio stream 
# use libvorbis (-c:a:137 libvorbis).
# 
# 
# HEVC Levels: http://hevc.info/HM-doc/_type_def_8h_source.html#l00590
# NONE	 = 0
# LEVEL1   = 30
# LEVEL2   = 60
# LEVEL2_1 = 63
# LEVEL3   = 90
# LEVEL3_1 = 93
# LEVEL4   = 120
# LEVEL4_1 = 123
# LEVEL5   = 150
# LEVEL5_1 = 153
# LEVEL5_2 = 156
# LEVEL6   = 180
# LEVEL6_1 = 183
# LEVEL6_2 = 186
# LEVEL8_5 = 255
# 
# H.264/AVC Levels
# 
# Levels specify the size of the video a decoder must be able to handle. They 
# specify a maximum bit-rate for the video and a maximum number of macroblocks 
# per second. Level numbers range from 1 to 5 with intermediate steps 
# (e.g., 1.1, 1.2, 1.3, etc.) A decoder operating at a particular level must 
# also handle all levels below.
# 
# List of all H.264/AVC Levels: 
# https://www.avidemux.org/admWiki/doku.php?id=tutorial:h.264#h264_avc_profiles_and_levels