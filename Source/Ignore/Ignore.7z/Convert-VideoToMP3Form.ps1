Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName PresentationCore, PresentationFramework
[System.Windows.Forms.Application]::EnableVisualStyles()
$FRMConvertVideoToMP3 = New-Object -TypeName System.Windows.Forms.Form
[System.Windows.Forms.ProgressBar]$PBTotalConversion        = $null
[System.Windows.Forms.Label]$LBLMainLabel                   = $null
[System.Windows.Forms.ProgressBar]$PBCurrentConversion      = $null
[System.Windows.Forms.Label]$LBLCurrentConversion           = $null
[System.Windows.Forms.Button]$BTNCancel                     = $null
[System.Windows.Forms.PictureBox]$ICOConversionIcon         = $null
function InitializeComponent {
    $resources                          = . (Join-Path $PSScriptRoot 'Convert-VideoToMP3Form.resources.ps1')
    $PBTotalConversion                  = (New-Object -TypeName System.Windows.Forms.ProgressBar)
    $LBLMainLabel                       = (New-Object -TypeName System.Windows.Forms.Label)
    $PBCurrentConversion                = (New-Object -TypeName System.Windows.Forms.ProgressBar)
    $LBLCurrentConversion               = (New-Object -TypeName System.Windows.Forms.Label)
    $BTNCancel                          = (New-Object -TypeName System.Windows.Forms.Button)
    $ICOConversionIcon                  = (New-Object -TypeName System.Windows.Forms.PictureBox)

    ([System.ComponentModel.ISupportInitialize]$ICOConversionIcon).BeginInit()

    $FRMConvertVideoToMP3.SuspendLayout()

    #PBCurrentConversion
    #
    $PBCurrentConversion.Location       = (New-Object -TypeName System.Drawing.Point -ArgumentList @([System.Int32]24, [System.Int32]127))
    $PBCurrentConversion.Name           = [System.String]'PBCurrentConversion'
    $PBCurrentConversion.Size           = (New-Object -TypeName System.Drawing.Size -ArgumentList @([System.Int32]484, [System.Int32]24))
    $PBCurrentConversion.TabIndex       = [System.Int32]2
    $PBCurrentConversion.Value          = 20
    $PBCurrentConversion.Style          = 'Continuous'
    #
    #PBTotalConversion
    #
    $PBTotalConversion.Location         = (New-Object -TypeName System.Drawing.Point -ArgumentList @([System.Int32]23, [System.Int32]173))
    $PBTotalConversion.Name             = [System.String]'PBTotalConversion'
    $PBTotalConversion.Size             = (New-Object -TypeName System.Drawing.Size -ArgumentList @([System.Int32]484, [System.Int32]24))
    $PBTotalConversion.TabIndex         = [System.Int32]0
    #
    #LBLMainLabel
    #
    $LBLMainLabel.AutoSize              = $true
    $LBLMainLabel.Font                  = (New-Object -TypeName System.Drawing.Font -ArgumentList @([System.String]'Segoe UI', [System.Single]14.25, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Point, ([System.Byte][System.Byte]0)))
    $LBLMainLabel.Location              = (New-Object -TypeName System.Drawing.Point -ArgumentList @([System.Int32]19, [System.Int32]20))
    $LBLMainLabel.Name                  = [System.String]'LBLMainLabel'
    $LBLMainLabel.Size                  = (New-Object -TypeName System.Drawing.Size -ArgumentList @([System.Int32]230, [System.Int32]25))
    $LBLMainLabel.TabIndex              = [System.Int32]1
    $LBLMainLabel.Text                  = [System.String]'Preparing to Convert Files'
    #
    #LBLCurrentConversion
    #
    $LBLCurrentConversion.AutoSize      = $true
    $LBLCurrentConversion.Font          = (New-Object -TypeName System.Drawing.Font -ArgumentList @([System.String]'Segoe UI', [System.Single]9.75, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Point, ([System.Byte][System.Byte]0)))
    $LBLCurrentConversion.Location      = (New-Object -TypeName System.Drawing.Point -ArgumentList @([System.Int32]21, [System.Int32]97))
    $LBLCurrentConversion.Name          = [System.String]'LBLCurrentConversion'
    $LBLCurrentConversion.Size          = (New-Object -TypeName System.Drawing.Size -ArgumentList @([System.Int32]395, [System.Int32]17))
    $LBLCurrentConversion.TabIndex      = [System.Int32]3
    $LBLCurrentConversion.Text          = [System.String]'Converting "C:\Users\futur\Desktop\Testing\Video Files\16bit.mov"'
    #
    #BTNCancel
    #
    $BTNCancel.AccessibleName           = [System.String]''
    $BTNCancel.DialogResult             = [System.Windows.Forms.DialogResult]::Cancel
    $BTNCancel.ForeColor                = [System.Drawing.SystemColors]::ControlText
    $BTNCancel.Location                 = (New-Object -TypeName System.Drawing.Point -ArgumentList @([System.Int32]410, [System.Int32]217))
    $BTNCancel.Name                     = [System.String]'BTNCancel'
    $BTNCancel.Size                     = (New-Object -TypeName System.Drawing.Size -ArgumentList @([System.Int32]98, [System.Int32]30))
    $BTNCancel.TabIndex                 = [System.Int32]4
    $BTNCancel.Text                     = [System.String]'Cancel'
    $BTNCancel.UseVisualStyleBackColor  = $true
    
    #
    #ICOConversionIcon
    #
    $ICOConversionIcon.Image            = ([System.Drawing.Image]$resources.'ICOConversionIcon.Image')
    $ICOConversionIcon.Location         = (New-Object -TypeName System.Drawing.Point -ArgumentList @([System.Int32]412, [System.Int32]2))
    $ICOConversionIcon.Name             = [System.String]'ICOConversionIcon'
    $ICOConversionIcon.Size             = (New-Object -TypeName System.Drawing.Size -ArgumentList @([System.Int32]98, [System.Int32]90))
    $ICOConversionIcon.TabIndex         = [System.Int32]5
    $ICOConversionIcon.TabStop          = $false
    #
    #FRMConvertVideoToMP3
    #
    $FRMConvertVideoToMP3.AccessibleName = [System.String]''
    $FRMConvertVideoToMP3.CancelButton = $BTNCancel
    $FRMConvertVideoToMP3.ClientSize = (New-Object -TypeName System.Drawing.Size -ArgumentList @([System.Int32]530, [System.Int32]270))
    #$FRMConvertVideoToMP3.AutoSize = $false
    #$FRMConvertVideoToMP3.Size
    $FRMConvertVideoToMP3.Controls.Add($ICOConversionIcon)
    $FRMConvertVideoToMP3.Controls.Add($BTNCancel)
    $FRMConvertVideoToMP3.Controls.Add($LBLCurrentConversion)
    $FRMConvertVideoToMP3.Controls.Add($PBCurrentConversion)
    $FRMConvertVideoToMP3.Controls.Add($LBLMainLabel)
    $FRMConvertVideoToMP3.Controls.Add($PBTotalConversion)

    $FRMConvertVideoToMP3.Font = (New-Object -TypeName System.Drawing.Font -ArgumentList @([System.String]'Segoe UI', [System.Single]9, [System.Drawing.FontStyle]::Regular, [System.Drawing.GraphicsUnit]::Point, ([System.Byte][System.Byte]0)))
    $FRMConvertVideoToMP3.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
    $FRMConvertVideoToMP3.MaximizeBox = $false
    $FRMConvertVideoToMP3.Name = [System.String]'FRMConvertVideoToMP3'
    $FRMConvertVideoToMP3.Text = [System.String]'VSYSFileOps VideoToMP3'
    $FRMConvertVideoToMP3.ShowIcon = $false

    ([System.ComponentModel.ISupportInitialize]$ICOConversionIcon).EndInit()

    $FRMConvertVideoToMP3.ResumeLayout($false)
    $FRMConvertVideoToMP3.PerformLayout()


    Add-Member -InputObject $FRMConvertVideoToMP3 -Name PBTotalConversion -Value $PBTotalConversion -MemberType NoteProperty
    Add-Member -InputObject $FRMConvertVideoToMP3 -Name LBLMainLabel -Value $LBLMainLabel -MemberType NoteProperty
    Add-Member -InputObject $FRMConvertVideoToMP3 -Name PBCurrentConversion -Value $PBCurrentConversion -MemberType NoteProperty
    Add-Member -InputObject $FRMConvertVideoToMP3 -Name LBLCurrentConversion -Value $LBLCurrentConversion -MemberType NoteProperty
    Add-Member -InputObject $FRMConvertVideoToMP3 -Name BTNCancel -Value $BTNCancel -MemberType NoteProperty
    Add-Member -InputObject $FRMConvertVideoToMP3 -Name ICOConversionIcon -Value $ICOConversionIcon -MemberType NoteProperty
}
. InitializeComponent

$FRMConvertVideoToMP3.ShowDialog()