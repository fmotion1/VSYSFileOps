
# Original Script Created by mklement0 on StackOverflow
#

function Request-Elevation {

    [CmdletBinding()]
    param(
        [switch]$NoExit,
        [switch]$HiddenWindow
    )

    $NoExitString = ($NoExit) ? '-noexit ' : ''
    $HiddenWindowStr = ($HiddenWindow) ? '-windowstyle hidden ' : ''

    if (-Not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] 'Administrator')) {
        if ([int](Get-CimInstance -Class Win32_OperatingSystem | Select-Object -ExpandProperty BuildNumber) -ge 6000) {
            $CommandLine = "-NoExit -c cd '$pwd'; & `"" + $MyInvocation.MyCommand.Path + "`""
            Start-Process pwsh -Verb runas -ArgumentList $CommandLine
            Exit
        }
    }

}