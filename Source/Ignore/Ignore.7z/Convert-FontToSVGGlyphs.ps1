$InputFont = "C:\Users\futur\Desktop\W10 Fonts Originals Copy\Feedback Hub Fluent Icons.ttf"
$InputUnescaped = $InputFont.Replace('`[', '[')
$InputUnescaped = $InputUnescaped.Replace('`]', ']')


D:\Dev\Python\FontTools\Scripts\Activate.ps1

fontforge -lang=ff -c 'Open($1); SelectWorthOutputting(); foreach Export("svg"); endloop;' $InputFont
