var colorsArray = [
    {
        color: "#FF9900",
        name: "Awesome Orange"
    }
];