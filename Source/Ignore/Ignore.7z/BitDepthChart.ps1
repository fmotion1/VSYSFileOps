name   depth
u8        8
s16      16
s32      32
flt      32
dbl      64
u8p       8
s16p     16
s32p     32
fltp     32
dblp     64
s64      64
s64p     64

-sample_fmt s16

MP3 "s16p,s32p,fltp"
AAC "fltp"
OGG "fltp"
WMA "fltp"
OPUS "s16,flt"
AC3 "fltp"
ac3_fixed "s16p"
FLAC "s16,s32"
