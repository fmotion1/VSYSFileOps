$VideoArr = @(
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\001%.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\70-BKB^ Brekete.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\83-PTY Dmbek1.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\bangguru-time_loser.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\control.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\current 93 live_teatro rasi_ravenna_03-06-2006 - part i.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\Erik&Truffaz.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\French.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\hc090_mandala_by_paperball.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\hc093_sad_song_full_res_by_fredo.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\KylieCan't.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\my_file'name.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\OMGDOGGE - Earthjoy - trailer.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\ovo.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\T-RackS Tu&torial.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\testing&video.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\The !Rodinians - Future Forest !Fantasy - FFF Trailer.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\Yelle - Je Veu&x Te Voir.mov",
    "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\yeongrak - yzome - infojunking - i n f o.mov"
)


# $VideoSingle = "C:\Users\futur\Desktop\Testing\Video Files\Dual Audio\Last_Exile_04 (1).mkv"
# Convert-FFMpegProbeVideos $VideoArr -StreamType Video
# Convert-FFMpegGetVideoStreams "C:\Users\futur\Desktop\Testing\Video Files\Lots of Streams\S01E02.The.White.Knight.Awakens.1080p.Dual.Audio.Bluray.mkv" -StreamType Format
# Convert-FFMpegProbeVideos "C:\Users\futur\Desktop\Testing\Video Files\Lots of Streams\S01E02.The.White.Knight.Awakens.1080p.Dual.Audio.Bluray.mkv" -StreamType All
Convert-FFMpegDemuxVideo $VideoArr -Verbose


# Convert-FFMpegVideoDemuxAudio $VideoArr -Verbose -OutputPath "C:\Users\futur\Desktop\Testing\Video Files\MOV ' Batch\Output"